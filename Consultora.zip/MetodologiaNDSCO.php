<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/BOOTSTRAP/css/bootstrap.min.css">
    <title>Metodología NDSCO</title>
</head>
<body>
<?php require('Navbar.php');?>      
    <div class="container">
        <div class="row ">
            <div class="col-6">
                <img src="/IMG/Metodología1.png" class="img-fluid " alt="">
            </div>
            <div class="col-6 pt-4 ">
                <h4 class="text-capitalize">Identificación de la situación actual</h4>
                <p>En este paso se determina el estado en que se encuentra la comunicación en la empresa, fundamentando el resultado a través de técnicas y herramientas de investigación en la comunicación social. Para ello se aplica, en primer lugar, un cuestionario tipo encuesta, La misma está encaminada a conocer la opinión de los trabajadores acerca de aspectos relativos a la comunicación organizacional.</p>
                <strong>En éstas se abordan los siguientes aspectos: </strong>
                <div class="row">
                    <div class="col-6 pe-3">
                        <ul class="list-group">
                            <li>Conocimiento acerca de la filosofía de la empresa </li>
                            <li>Nivel de centralización en la toma de decisión </li>
                            <li>Condiciones laborales </li>
                            <li>Ambiente de trabajo en relación a la comunicación</li>
                            <li>Características del ambiente interno </li>
                            <li>Cooperación entre áreas de trabajo </li>
                        </ul>                        
                    </div>
                    <div class="col-6">
                        <ul class="list-group">
                            <li>Principales canales de comunicación </li>
                            <li>Tipo de información que se trasmite </li>
                            <li>Retroalimentación </li>
                            <li>Grado de identificación con la empresa </li>
                            <li>Sistema de valores compartidos </li>
                            <li>Historia de la organización</li> 
                        </ul>
                    </div>
                </div>

            </div>
        </div>
        <div class="row pt-3">
            <div class="col-12">
                <p>Dicho cuestionario-encuesta se procesa estadísticamente y se realiza el cruzamiento de las múltiples variables cualitativas que se miden. Los capítulos para determinar la situación actual percibida se agrupan de la siguiente manera:</p>
                <li>Historia e identidad corporativa </li>
                <li>Evaluación y perspectivas </li>
                <li>Consideraciones y flujos de comunicación </li>
                <li>Opiniones y ambiente interno </li>
                <li>Comunicación, percepción y clima </li>
                <li>Canales de comunicación y sentido de pertenencia </li>
                <li>Sistema de valores compartidos </li>               
                
                <h4 class="text-capitalize pt-3">Análisis de la función de dirección en el proceso de comunicación</h4>
                <p>En este paso se realiza un estudio sobre cómo influyen los directivos en la empresa, su papel, qué rol desempeñan, qué tan competentes son y si presentan o no competencia para la comunicación. Para ello se utiliza un cuestionario tipo encuesta basado en la estructura de la competencia para la comunicación. 
                Para conocer las brechas de criterios entre cada nivel dentro de la organización, se procede a la aplicación de la técnica 360. Esta última permite retroalimentar ampliamente el criterio autoevaluación de directivos, subordinados y colegas; y de este modo determinar las brechas entre cada una de las opiniones expuestas.</p>

                <h4 class="text-capitalize pt-2">Proyección del Plan de Acción</h4>
                <p>En este paso se determinan y crean las acciones encaminadas a instituir un Sistema de Comunicación Empresarial eficaz como primer paso. 
                Se creará un grupo interdisciplinario que pertenezca a la empresa para evaluar si este plan es oportuno y procedente, o no; y se presentará a  Dirección para su aprobación final.</p>
                
                <h4 class="text-capitalize pt-2">Proceso de mejora continua</h4>
                <p>Se evalúa y determina por el encargado de Comunicación de la Empresa cada qué tiempo se debe verificar, corregir y mejorar la situación de la comunicación dentro de la empresa, de manera que esto se convierta en algo cíclico y cada vez se mejore un poco más. 
                La propuesta principal es que el naciente sistema de comunicación se sustente sobre una base con una proyección en la prospectiva estratégica de un horizonte de 3 años, donde coincidentemente con ese tiempo, se implementen sistemáticamente diagnósticos de comunicación como parte de su mejora continua. </p>
            </div>

        </div>


    </div>


<?php include('Footer.php');?>
<script src="/BOOTSTRAP/js/bootstrap.bundle.js"></script>
</body>
</html>