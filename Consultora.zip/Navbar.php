<style>
    .fondo-nav{
        background-color: rgb(29,55,98);
        
    }
    
    
</style>
<nav class="row  pt-sm-3 pb-sm-3 pe-1 text-center justify-content-end fs-5 shadow fondo-nav ">
        <div class="d-none d-sm-block col-sm-3 col-md-2 col-lg-1 "><a href="index.php" class="link-light text-decoration-none">Inicio</a>       </div>
        <div class="d-none d-sm-block col-sm-3 col-md-2 col-lg-1 "><a href="Nosotros.php" class="link-light text-decoration-none">Nosotros</a>  </div>
        <div class="d-none d-sm-block col-sm-3 col-md-2 col-lg-1 "><a href="Contacto.php" class="link-light text-decoration-none">Contacto</a>  </div>
        <div class="d-none d-sm-block col-sm-3 col-md-2 col-lg-1 "><a href="Servicios.php" class="link-light text-decoration-none">Servicios</a></div>
        <div class="d-block d-sm-none dropdown text-end">
            <button
                class="btn btn-dark dropdown-toggle "
                type="button"
                id="dropdown-1"
                data-bs-toggle="dropdown"
                aria-expanded="false"
            >
            Menú
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdown-1">
                <li><a href="index.php" class="dropdown-item">Inicio</a></li>
                <li><a href="Nosotros.php" class="dropdown-item">Nosotros</a></li>
                <li><a href="Contacto.php" class="dropdown-item">Contacto</a></li>
                <li><a href="Servicios.php" class="dropdown-item">Servicios</a></li>
            </ul>
        </div>
</nav>